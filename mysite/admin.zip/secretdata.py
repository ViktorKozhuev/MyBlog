secretkey = 'agajenvl#%8'
admin_name = 'viktor'
admin_password = 'roTkiv#1371'